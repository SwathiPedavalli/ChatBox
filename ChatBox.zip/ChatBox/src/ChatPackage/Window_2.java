package ChatPackage;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Window_2 extends JFrame {
    static String Username2;
	private JPanel contentPane;
	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Window_2 frame = new Window_2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Window_2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 310, 401);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		display2 = new JTextArea();
		display2.setBounds(10, 65, 274, 204);
		contentPane.add(display2);
		display2.setColumns(10);
		
		text2 = new JTextArea();
		text2.setBounds(25, 300, 163, 51);
		contentPane.add(text2);
		text2.setColumns(10);
		
		 send2 = new JButton("SEND");
		send2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = text2.getText();
                if(s.equals("")) {
                          return;
                }
                display2.append(Username2 + ":" + s + "\n");
                Window_1.sendText();
                text2.setText("");
			}
		});
		send2.setBounds(205, 300, 89, 51);
		contentPane.add(send2);
		
		 clear2 = new JButton("CLEAR");
		clear2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				display2.setText("");
			}
			
		});
		clear2.setBounds(195, 11, 89, 43);
		contentPane.add(clear2);
		
		label2 = new JLabel("\"Chat Window for : \" + Username2");
		label2.setBounds(25, 11, 140, 39);
		contentPane.add(label2);
	}
	
	public static void sendText() {
        String s= Window_1.text1.getText();
        if (s.equals("")) {
                 return;
        }
        display2.append(Window_1.Username1 + ":" + s + "\n");
  }
    private static javax.swing.JTextArea display2;
    private javax.swing.JButton send2;
    public static javax.swing.JTextArea text2;
    private JButton clear2;
    private JLabel label2;
    }
